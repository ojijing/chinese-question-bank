@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PY=%~dp0runtime\python.exe
set PYTHONPATH=%~dp0;%~dp0runtime\Lib\site-packages
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

echo ==== Python ====
"%PY%" -c "import sys; print(sys.version); print(sys.executable); print('PYTHONPATH OK:', 'backend' in ' '.join(sys.path))"
echo.
echo ==== Dependencies ====
"%PY%" -c "import fastapi, uvicorn, openpyxl, docx; print('dependencies OK')"
echo.
echo ==== Database ====
if exist "%~dp0data\data.db" (echo data\data.db OK) else (echo [ERROR] data\data.db missing)
echo.
echo ==== Backend import ====
"%PY%" -c "from backend.app.main import app; print('backend import OK')"
echo.
echo ==== Built-in converter ====
"%PY%" -c "from backend.app.services.html_to_docx import html_to_docx_bytes; print('docx bytes', len(html_to_docx_bytes('<p>ok</p>')) > 0)"
echo.
echo If any error is shown above, please send a screenshot of this window.
pause
