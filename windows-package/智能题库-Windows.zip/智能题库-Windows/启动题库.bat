@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PY=%~dp0runtime\python.exe
set PYTHONPATH=%~dp0;%~dp0runtime\Lib\site-packages
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set HOST=127.0.0.1
set PORT=8000

if not exist "%PY%" (
  echo [ERROR] Missing runtime: %PY%
  pause
  exit /b 1
)

if not exist "%~dp0data\data.db" (
  echo [ERROR] Database not found: data\data.db
  echo Please copy your database file into the data folder and name it data.db.
  pause
  exit /b 1
)

echo Starting question bank with built-in HTML2DOCX on port 8000 ...
start "TIKU-8000" cmd /K ""%PY%" "%~dp0main.py""
timeout /t 4 /nobreak >nul

netstat -ano | findstr ":8000" >nul
if errorlevel 1 (
  echo [ERROR] Port 8000 is not listening. Check the TIKU-8000 window.
  pause
  exit /b 1
)

start http://127.0.0.1:8000
echo.
echo Running: http://127.0.0.1:8000
echo HTML2DOCX built in: http://127.0.0.1:8000/api/html2docx
echo Keep the TIKU-8000 window open. Use 停止服务.bat to stop it.
echo.
pause
