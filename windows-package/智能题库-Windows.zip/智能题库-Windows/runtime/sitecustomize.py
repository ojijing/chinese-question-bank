import os
import sys

_BASE = os.path.dirname(sys.executable)
_ROOT = os.path.dirname(_BASE)
_SITE = os.path.join(_BASE, "Lib", "site-packages")

for path in (_ROOT, _SITE):
    if os.path.isdir(path) and path not in sys.path:
        sys.path.append(path)
