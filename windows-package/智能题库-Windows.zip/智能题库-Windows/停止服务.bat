@echo off
chcp 65001 >nul
taskkill /FI "WINDOWTITLE eq TIKU-8000*" /F >nul 2>&1
echo Service stopped.
pause
